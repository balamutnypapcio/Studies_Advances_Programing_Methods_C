#ifndef PREPROCESSOR_HH
#define PREPROCESSOR_HH

#include <string>

// Przetwarza plik za pomocą preprocesora C i zwraca wynik jako string
std::string PreprocessFile(const std::string& filename);

#endif